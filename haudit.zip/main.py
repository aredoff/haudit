# from ssh import SSHUtil
#
# hostname = 'officeradio.hosterby.com'
# username = 'root'
# password = 'hosterroot'
#
# ssh_util = SSHUtil(hostname, username, password)
# command = 'systemctl'
#
# print(ssh_util.execute_command(command))
# # ssh_util.upload_file("E:\\a.png", "/root/a.png")
# # ssh_util.download_file('/root/a.png', 'E:\\a.png')
# print('end')ж
# import sys
# print(sys.executable)
# exit()

# res = 0
# d = {'a': 1, 'b': 2}
# for key, val in d.items():
#         exec(key + '=val')
# print(a)
#
# exit()

#
# import ast
# val = 'auto'
#
# val = ast.literal_eval(val)
# print(type(val))
#
# print(eval("val>3 or val<0"))
# exit()


# def import_from(module, name):
#     module = __import__(module, fromlist=[name])
#     return getattr(module, name)
#
#
# t = import_from("plugins.linux_system.mods.test", "test1")
# print(t.c)
#
# exit()

from audit import Audit
from dotenv import load_dotenv

load_dotenv()


a = Audit()
report = a.execute_queries()
a.printReport(report)
