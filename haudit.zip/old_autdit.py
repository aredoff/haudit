import os
from os.path import isfile, join
import json
from ssh import SSHUtil
import re
import subprocess


class Audit():
    plugins_folder = 'plugins'
    hostname = 'officeradio.hosterby.com'
    username = 'root'
    password = 'hosterroot'

    def __init__(self):
        self.sshClient = SSHUtil(hostname=self.hostname, username=self.username, password=self.password)
        self.plugins = []
        for plugin_folder in os.listdir(self.plugins_folder):
            plugin = {
                'name': plugin_folder,
                'folder': self.plugins_folder + '/' + plugin_folder,
                'queries': [],
            }
            for file in os.listdir(plugin['folder']):
                if file.endswith('.json'):
                    with open(os.path.join(plugin['folder'], file), 'r') as f:
                        plugin_jsons_data = json.loads(f.read())
                        if 'queries' in plugin_jsons_data:
                            plugin['queries'].append(*plugin_jsons_data['queries'])

            self.plugins.append(plugin)


    def _executeMod(self, params, modPath):
        p = subprocess.Popen([modPath,], stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate(input=json.dumps(params).encode())
        print(out,err)
        return out.decode("utf8", "ignore")


    def execute_queries(self):

        for plugin in self.plugins:
            plugin_report = {
                'name': plugin['name'],
                'queries': [],
            }
            for querie in plugin['queries']:
                command_output = self.sshClient.execute_command(querie['command'])
                querie_report = {
                    'status': 'ok',
                    'params': []
                }
                if command_output:
                    for parameter in querie['params']:
                        parameter_regex = re.findall(parameter['regex'], command_output)
                        if parameter_regex:
                            querie_report['params'].append({
                                'status': 'ok',
                                'name': parameter['name'],
                                'value': parameter_regex[0],
                            })
                        else:
                            querie_report['params'].append({
                                'status': 'error',
                                'name': parameter['name'],
                            })
                    if 'mods' in querie:
                        for mod in querie['mods']:
                            querie_report['params'] = self._executeMod(querie_report['params'], os.path.join(os.getcwd(), plugin['folder'] + '/mods/' + mod) )

                else:
                    querie_report['status'] = 'error'
                plugin_report['queries'].append(querie_report)
        # print(plugin_report)


        # onlyfiles = [f for f in listdir(self.plugins_folder) if isfile(join(self.plugins_folder, f))]
        # print(plugins)
