from core import ModClass

class Mod(ModClass):
    a = 1
    b = 2
