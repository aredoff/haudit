import paramiko
import time
from pathlib import Path
import select

host = 'officeradio.hosterby.com'
user = 'root'
secret = 'hosterroot'
port = 22

# pkey_password = ''
# pkey = paramiko.RSAKey.from_private_key_file(str(Path.home()) + "/.ssh/id_rsa", pkey_password)


client = paramiko.SSHClient()
client.load_system_host_keys()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

client.connect(hostname=host, username=user, password=secret, port=port)
# client.connect( hostname=host, username=user, pkey=pkey)

channel = client.get_transport().open_session()
channel.exec_command('systemctl')

output = ''
while True:
        if channel.exit_status_ready():
            break
        r, w, x = select.select([channel], [], [], 10.0)
        if len(r) > 0:
            output += str(channel.recv(1024))

print(output)

# stdin, stdout, stderr = client.exec_command('ls -l')

# time.sleep(1)
# data = stdout.read() + stderr.read()
# print(data)
client.close()